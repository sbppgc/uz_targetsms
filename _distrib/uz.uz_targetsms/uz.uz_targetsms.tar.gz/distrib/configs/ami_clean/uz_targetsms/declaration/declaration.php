<?php
// {{}}
$oDeclarator->startConfig('##section##', ##taborder##);
$oDeclarator->register('ami_clean', 'uz_targetsms', '##modId##', '', AMI_ModDeclarator::INTERFACE_ADMIN);
$oDeclarator->setAttr('##modId##', 'id_pkg', '##pkgId##');
$oDeclarator->setAttr('##modId##', 'id_install', '##installId##');
