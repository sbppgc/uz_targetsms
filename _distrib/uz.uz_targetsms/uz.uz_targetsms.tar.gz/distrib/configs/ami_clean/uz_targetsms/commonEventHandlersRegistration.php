<?php

$GLOBALS["uzTargetsmsModId"] = "##modId##";
include_once($GLOBALS["ROOT_PATH"].'_local/modules/code/AmiClean_UzTargetsms_Handlers.php');
