<?php
/**
 * @copyright Ugol Zreniya. All rights reserved.
 * @category  Module
 * @package   Module_##modId##
 */

/**
 * ##modId## module rules.
 *
 * @package    Module_##modId##
 * @subpackage Rules
 */
class ##modId##_Rules extends AmiClean_UzTargetsms_Rules{
}
