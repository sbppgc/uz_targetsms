<?php
/**
 * AmiClean/UzTargetsms configuration.
 *
 * @copyright Ugol zreniya. All rights reserved. Changes are not allowed.
 * @category  Config
 */

/**
 * AmiClean/UzTargetsms configuration rules.
 *
 * @package    Config_AmiClean_UzTargetsms
 * @subpackage Controller
 */
class AmiClean_UzTargetsms_Rules extends Hyper_AmiMultifeeds_Rules{
}
