<?php
/**
 * @copyright Ugol Zreniya. All rights reserved. Changes are not allowed.
 * @category  Module
 * @package   Module_##modId##
 */

/**
 * ##modId## module table item model modifier.
 *
 * @package    Module_##modId##
 * @subpackage Model
 */
class ##modId##_TableItemModifier extends AmiClean_UzTargetsms_TableItemModifier{
}
