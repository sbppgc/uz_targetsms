<?php
/**
 * AmiClean/UzTargetsms configuration.
 *
 * @copyright Ugol zreniya. All rights reserved. Changes are not allowed.
 * @category  Config
 * @package   Config_AmiClean_UzTargetsms
 */

/**
 * AmiClean/UzTargetsms configuration table item model modifier.
 *
 * @package    Config_AmiClean_UzTargetsms
 * @subpackage Model
 */
class AmiClean_UzTargetsms_TableItemModifier extends Hyper_AmiClean_TableItemModifier{
}
